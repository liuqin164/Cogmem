# Changelog

## 4.0.0

- A Night with work now reconciles the atlas **once** instead of twice. `runNight` called `runMaintenanceTick`, which reconciles, and then reconciled again at the end; the first pass ran *before* Dream wrote the frames it exists to notice, so a night with any new conversation paid two corpus-wide rebuilds (17.4 s each at 20k events). The tick's pass is skipped when `runNight` is the caller (`MaintenanceTickOptions.atlasRefresh`), and a skipped pass reports `skipped: true` rather than `refreshed: false`, because "the projection was current" and "this pass did not run" are different facts. The standalone `memory tick` and the MCP maintenance tool are unchanged.
- Removed 179 lines of code nothing referenced: `src/utils/vector.ts` entire, fifteen exported functions across `src/`, and the unused `zod` dependency. Also removed a dead module (`ObservationHygieneRules`) and four declarations that had lost their only reader in the same pass. No public export changed: `src/public.ts` still exports the same surface.

- Host configurations now name a managed launcher instead of an installation path (#114). `cogmem init` and `cogmem connect` write `~/.cogmem/bin/cogmem` (one per user, `COGMEM_SHIM_DIR` overrides it) and point every host entry at it; that launcher resolves the installation when the host runs it — `COGMEM_BIN`, then the installation recorded beside it, then the first `cogmem` on `PATH` that is not itself — so an upgrade, a moved checkout, a changed npm prefix or a different package manager no longer invalidates a configuration written earlier. With nothing to run it says so and exits 127 rather than running something else. `cogmem doctor` warns when the launcher is missing or points at nothing. This is the root cause behind #86, #94 and #96, which were each answered by noticing harder instead of by not writing the path.
- A turn the caller names is now an identity (#113). `cogmem_remember_turn` exposes `turnId`, and the same `turnId` with the same text writes nothing the second time and returns the turn already recorded instead of a second copy; the same `turnId` with different text is refused as `agent_turn_identity_conflict`. The event ids are derived from stable fields only — the previous fallback named a turn after `Date.now()` and an incrementing sequence, so a retry of one named turn left seven events with the user and assistant rows byte-identical. Callers that pass no `turnId` are unchanged: the turn is still written, under a synthesized name, and a retry is still a second copy.
- Removed 18 declarations nothing referenced, 199 lines: `summarizeAlgorithmReviewMetrics`, `createAlgorithmReviewBackend`, `createDefaultVectorCandidateFilter`, `validCalendarDate` and `drainRememberQueue` (each the only reader of its helpers), and the types `ProjectionObservabilityStats`, `BackgroundJobStatus`, `BrainMetrics`, `BackupConfig`, `UnifiedAuditBundle`, `RetrievalCacheStats`, `NoopQueryTimePendingEntityResolutionHook`, `CanonicalMemoryCandidate`, `BackupRecord`, `MigrationRecord`, `EntityAliasRecord`. Most were reachable through the `./internal` barrel, which is why nothing reported them: a barrel publishes a name without ever reading it.
- Removed `src/batch/SourceOnboarding.ts` (482 lines) before release: all ten of its exports — the source-preflight report types, `classifyLane`, `inspectSources`, the two strict-failure evaluators and `formatPreflightSummary` — were referenced nowhere in the repo, and the module was reachable only through the `./internal` barrel. A batch preflight that no command calls is a promise the release cannot keep; it comes back with the command that needs it.
- Removed the domain-level persistence ports (`src/ports/index.ts`) and their SQLite adapter before release: the raw-ledger, episode, graph, recall and governance ports had no consumer in the kernel and were not on the published surface, so the only user was the adapter's own test. A port with no consumer is a second access path to maintain for nobody. The shared-region port and its adapter stay for 4.1 (see the shared-memory entry below), unexposed as before.
- Added a shared memory region internally: idempotent publish on `itemHash`, soft retraction that stays explainable, and publisher-only retraction. 4.0 does **not** expose it. No tool profile registers a shared-memory tool and starting a server no longer creates the region's storage, because the three things it needs are not in this release: a trusted per-agent identity, per-collection read permission, and provenance labelling that keeps another agent's memory at lower trust. The port and its SQLite adapter stay in the tree for 4.1, reachable from neither the MCP surface nor a package entry point. A call naming one of the removed tools answers `tool_not_found` rather than `tool_not_in_profile`, because no profile can reach it and there is nothing to widen.
- Added Streamable HTTP transport for the MCP server. One kernel per process preserves the single-writer rule; one transport per MCP session follows the SDK's stateless-transport constraint.
- Added server-side tool profiles: `core` (6), `admin` (22), `full` (36), enforced on both `tools/list` and `tools/call`.
- Added three import MCP tools over the existing `import-hermes` / `import-openclaw` pipeline: `cogmem_import_preview` (dry-run source discovery and record counts), `cogmem_import_apply` (idempotent ingest through `recordRawEvent` → vectorize → consolidate → Atlas rebuild), and `cogmem_import_status` (per-project processed source IDs and diagnostics).
- Added `--project` connection binding: a connection is scoped to one project, and a call naming a different project is rejected with `project_scope_violation`.
- Added `cogmem init --no-probe`, which skips the `localhost:11434` Ollama probe so the generated `vector_dimension` depends only on the arguments and not on whichever embedding model the local daemon happens to expose.
- Breaking for a host that was already pointing at a shared-memory tool: 4.0 does not ship the four shared-memory MCP tools this unreleased cycle had added. The endpoints return `tool_not_found`, and a fresh database no longer carries the region's table. Shared memory returns in 4.1 as an opt-in feature behind per-agent identity, read permission, and provenance labelling.
- Added host configuration for Claude Code, Cursor, Codex, and Hermes in `docs/mcp-hosts.md`.
- MCP `instructions` now follow the serving profile: a `core` server stops naming tools it filters out, and every profile keeps the explicit-recall contract for a host with no Cogmem adapter, whether it exposes a push hook or not.
- Documented how memory reaches the model per host, separating what a host exposes (a push hook) from what Cogmem ships for it (a host adapter). Three hosts have a shipped and verified adapter, so memory emerges there today: OpenClaw (its plugin, `before_prompt_build`), pi (an extension `connect pi --auto` writes, `before_agent_start`), and Hermes (a `pre_llm_call` shell hook `connect hermes --auto` writes). DSH (a prompt section) and Claude Code (`UserPromptSubmit`) expose a push hook but ship no adapter yet, and stay on the explicit-recall path with the MCP-only hosts (Cursor, Codex, and any host attached with `mcp add`). `docs/mcp-hosts.md` states the path and the adapter status per host, and the README carries the adapter roadmap.
- Added `cogmem memory belief-history --key <canonicalKey>`, which returns every version of a belief oldest-first with its validity interval and the version that replaced it. Current recall still suppresses superseded values.
- `memory plan` and `memory govern --status needs_confirmation` now hand out one runnable shape per review action (`reviewCommands`) instead of a single `<approve|reject|defer|supersede|relink>` line: approve and relink carry `--confirmation-event`, relink also carries `--target-belief`, and defer carries a future `--review-after`. The single shape used to fail on first paste for those three actions (`confirmation_event_required`, `review_after_must_be_in_the_future`). The `cogmem_candidate_review` description now names the same per-action inputs.
- `memory review --action supersede` now rejects a `--replacement` that names the candidate being reviewed (`replacement_candidate_must_differ`). Before, `--replacement <itself>` was accepted and wrote a `replacement_candidate` target pointing back at the row it had just closed, so following "what replaced this?" landed on a superseded candidate. The supersede shape in `reviewCommands` now carries `--replacement <replacement-candidate-id>` to match the shipped Hermes and OpenClaw runbooks, and the replacement placeholder is no longer spelled the same as `--id` in either runbook, which made the documented command a self-supersede when filled in with one id.
- `memory review --action supersede` now requires `--replacement` (`replacement_candidate_required`). Omitting it used to succeed and write `promotion_target_type = 'manual_review'` with `promotion_target_id` set to the candidate's own id, so the one question that column answers ("what replaced this?") pointed back at the row the review had just closed. Supersede now always writes `replacement_candidate` plus the named candidate, and retiring a candidate with no successor is a `reject`. The `cogmem_candidate_review` description, the `memory review` usage, and both shipped runbooks say the replacement is required.
- Automatic retirement no longer names the retired candidate as its own promotion target. Review-queue expiry (`review_queue_expiry`) and the dream curator's provider-recovery cleanup (`diagnostic_conclusion`) both used to write `promotion_target_id = <the candidate's own id>`, so a candidate that simply aged out claimed it had been replaced by itself. Both paths now leave `promotion_target_id` empty and keep the reason in `status_reason`; `promotion_target_type` holds either the referent (`fact`, `belief`, `entity`, `graph_edge`, `replacement_candidate`) or, for a candidate retired without a successor, the reason class. `GLOSSARY.md` states the rule and no status update in `src/` may name its own row.
- A promoted semantic organization candidate no longer names itself as its promotion target. `DeepWritePromotionPolicy.promoteOrganizationCandidate` fell back to `candidate.candidateId` when the candidate had no earlier target and its content carried none of `sourceEventId` / `targetEventId` / `topicPath`, so a `semantic_tags` / `indexing_decision` / `correction` row could claim to be about itself. The fallback is gone: `promotion_target_type` still records the reason class, `promotion_target_id` stays empty when there is no referent, and the referents that do exist (event id, topic path, or a target an earlier pass recorded) are still written.
- `memory review --action relink` now moves every target-bearing field of the correction to the named belief. Before, it rewrote `correctedClaimKey` and `targetBeliefId` but left `correctedBeliefCandidateIds` (and the resolver verdict `correctionResolution` / `correctionResolutionReason`) on the old target, so one content object named two different beliefs and a promoted record still read `needs_review` / `claim_key_match`. Relink now writes `correctedBeliefCandidateIds: [<belief>]`, marks the resolution `manual_relink` / `operator_target_belief`, and records a target it moved away from as `relinkedFromBeliefId`. Both shipped runbooks and the `cogmem_candidate_review` description say relink binds rather than validates.
- `memory review` now rejects an input the chosen action does not consume (`review_input_not_applicable:<field>`). The audit row in `deep_write_candidate_reviews` is append-only evidence, and it used to be written from the raw request: `--action approve --target-belief <b>` stamped `target_belief_id = <b>` on a review that never bound anything, `--action reject --review-after <t>` recorded a deferral that never happened, and `--action supersede --confirmation-event <e>` claimed user evidence for the one action that never asks for it. Consumed inputs are confirmationEventId for approve and relink, targetBeliefId for relink, replacementCandidateId for supersede, reviewAfter for defer, and none for reject; anything else fails before any write.
- Atlas matched facets carry `productFacet` when the entrance stands for one of the six a person can name (`entity` → `person`, `location` → `place`, `state` → `state`, `actor` → `person`, `memoryKind: event` → `event`); internal entrances carry `internal: true`, and `whyMatched` reads in the product word.
- Documented the `x-cogmem-identity` header and its trust boundary: an unauthenticated header may narrow the tool profile but never widen it past the launch profile, a token removes that ceiling, and a differing `projectId` is rejected rather than applied.
- Breaking: the `x-cogmem-identity` header no longer sets `hostId` on an unauthenticated connection. A `hostId` says which agent a call runs as, so it is honoured only when the transport authenticated the request; without a token the field is ignored and the call runs as the server, never as the name in the header. This closes the case where any local process that could reach a loopback port promoted itself to another agent's identity by asking. The `projectId` and `profile` fields behave as before, because they narrow what the connection may do instead of inventing who it is.
- Added agent registration for several agents behind one resident server: `<workspace>/.cogmem/agents.json`, falling back to `~/.cogmem/agents.json`, or `--agents <path>`, registers each agent with its own credential, and that credential decides the connection's `hostId`, the project it is confined to, and its tool-profile ceiling. A request presenting no registered credential is refused with `401` even on loopback, a session cannot be ridden by another agent's credential, and a header may narrow those fields but never change them — a disagreeing `hostId` is rejected with `host_identity_mismatch`. Readers look in the Workspace first, then beside the home directory, so a registration written under a project scope is found from any directory; a `.cogmem/` that holds a registry but no config is searched for too, because `cogmem init --register-agent <hostId>` writes there and deliberately leaves `config.toml` alone (repeatable, printed once, `--rotate` to replace an existing credential, `--dry-run` to report without writing). `cogmem-host-bridge` accepts the same credential through `--token` or `COGMEM_AGENT_TOKEN`, and the stdio transport reads it from `COGMEM_AGENT_TOKEN`. A credential that cannot be identified is **refused**, never served as an anonymous single agent with project access: that covers a credential presented when no registry can be found, and a registry named by `--agents` that cannot be read. No registry *and* no credential is still the supported single-agent case, which is a different answer.
- `cogmem memory show --event <id>` no longer reads across projects: a project-bound drill-down refuses an event owned by another project with the same "not found" message, so it does not confirm that the event exists elsewhere.
- Breaking: 4.0 is a clean start and does not migrate or upgrade a pre-4.0 database. Opening a Cogmem 3.x file is refused with an error code beginning `no_upgrade_path:`, and the file is left exactly as it was — not backed up, not partially rewritten. Keep the old file for Cogmem 3.x, or point 4.0 at a new database path (a new `db_path` in the config, or `--db` for one command) and move history across from the 3.x install. Creating a new 4.0 database still works and is the supported path.
- `cogmem update` no longer runs a migration step: it updates the package, refreshes host integration files when they are configured, and ends on the same install gate a fresh install ends on. The `--skip-migrate` flag is gone, and `--json` no longer reports `migrationCommand` or `migrationSkippedReason`. The database-upgrade commands and the packed-migration release gate are removed along with the upgrade path.
- There are now two documented install paths instead of five, differing only in who answers the setup questions: an operator runs the installer then `cogmem init`, an agent runs the installer then `cogmem init --yes`. The npm, `bun add`, npm-with-Bun and global-npm variants moved to an appendix for projects that already have a JavaScript workspace.
- Breaking: the one-line installer no longer runs the setup wizard. It installs, links the CLI and stops, so `curl | bash` can no longer ask questions on one machine and write a config nobody chose on another. `COGMEM_SKIP_INIT` is still accepted and now does nothing. Run `cogmem init` afterwards.
- Breaking: `cogmem doctor` is the install gate and reports four outcomes instead of pass/fail. A missing config is *not installed* and exits 0 with the command that configures it, where it used to be `FAIL` with exit 1. `rule_only` and a CLI directory outside `PATH` are WARNs: working but degraded. Only a genuine failure exits non-zero. `--json` returns `installGate` plus `nextSteps`.
- Breaking: `cogmem init --yes` no longer picks a model provider or copies an API key from the environment. Human-required settings — provider choice, any key, the encryption passphrase, host integration switches — fall back to conservative values and are reported as warnings, so an unattended install ends in `rule_only` rather than in a paid provider nobody approved or a database nobody can open. `--agent` used to fall back to auto-detection and now defaults to `none` for unattended runs; host detection is printed as a suggestion and changes nothing on disk.
- `cogmem init --yes` defaults to project scope and `cogmem init` to global scope, so an agent configures the workspace it was pointed at while an operator configures the machine. `--scope` overrides either. `--json` reports the written config, every warning, and the next step.
- `cogmem update` ends on the same install gate and inherits its exit code, so post-update verification is the same contract as a fresh install. `--json` gains `installGate` and `nextSteps` beside the existing install-kind fields.
- Breaking: the MCP server now defaults to the `core` profile. A host that expects every tool must start with `--profile full`.
- Storage note: 4.0.0 ships on SQLite. The seekdb backend was evaluated in `docs/superpowers/specs/2026-10-22-cogmem-seekdb-evaluation.md` and is conditionally approved pending x86_64 and macOS verification; it lands behind the same ports in a later release.

## 3.7.5

- Fixed OpenClaw auto-memory prompt serialization so generated plugins correctly sanitize control characters and whitespace without invalid runtime regular expressions.

## 3.7.4

- Added evidence-backed MemoryFrame V1 contracts, controlled relation validation, canonical alias normalization, and bounded MemoryQueryFrame helpers.
- Added one formal schema migration, 0032, from the released 3.7.3/schema-31 database to the complete 3.7.4 schema. Unreleased development schemas are rejected instead of becoming permanent compatibility history.
- Added staged MemoryFrame revisions, Atlas aliases/supports, V2 projection provenance, project-scoped graph identities, resumable topology rebuilds, and the final isolation constraints inside that atomic release migration.
- Wired structured processor output through staged Dream publication, paginated Atlas V2 projection, temporal/state projection, alias resolution, Repair invalidation, and forget-user cleanup.
- Connected bounded multidimensional Atlas seed/path results to kernel and agent recall while preserving collection, workspace/session/thread scope, and retrieval-lane governance. Rule-only installations now report `semantic_processor_unavailable` instead of silently presenting fallback semantics as complete.
- Made recall and MCP graph discovery read-only over last-known-good projections, added explicit paginated `cogmem memory rebuild-topology --project <id>`, and rebuilt topology plus cognitive temporal edges through resumable staging and a final atomic project-local swap.
- Bound the 0032 receipt digest to the release entrypoint and every internal atomic install source, and verified a real `main@b4733454` 3.7.3 database upgrades with one receipt.
- Hardened import date provenance and explicit `--db` timezone diagnostics, made Frame baseline reduction idempotent across repeated direct rebuilds, and aligned MemoryFrame schema bounds with runtime validation.
- Scoped topology, entity, event, policy-execution, runtime, Atlas, and projection identities. Unscoped 3.7.3 runtime read-model rows are treated as disposable runtime state: migration requires a backup, reports the discarded count, and retains only hash-based discard receipts.
- Made policy side effects require a caller-owned operation identity, atomically lease execution, validate terminal outcomes, preserve legacy idempotency tombstones, and recover pending audit events after restart without bypassing retry schedules.
- Rebuilt policy/runtime projections with filtered global-sequence pages, fixed high-water checkpoints, and shadow tables that atomically replace the live read model without exposing empty or partial rebuilds.
- Scoped runtime state, transition, outbox, and projection rows by project, included them in privacy erasure, and made standalone stores fail explicitly when opened before the required migration.
- Restricted Atlas dirtying to user/tool evidence, projected MemoryFrames before aggregate/project counts, merged action evidence into time facets, and tightened multilingual action/target parsing.
- Extended read-only status with the pending policy-audit outbox count and added migration, isolation, crash-recovery, timezone, parser, and privacy regression coverage.
- Reduced multi-authority graph edges from project-scoped support rows, so Frame/Curator withdrawal immediately restores the surviving edge without stale evidence or a second rebuild; aligned the public edge contract, binding invariants, and recall-governance SQL with runtime behavior.
- Split edge-support updates into append, replace, and lifecycle revision semantics so Curator/Frame rebuilds can remove stale evidence and lower projection strength after episode repair while repeated rebuilds remain version-idempotent.
- Aggregated duplicate relation, temporal, and state fragments inside each MemoryFrame before replacing its edge support, making evidence, confidence, validity, and rebuild versions independent of array order while preserving snapshot shrink.

## 3.7.3

- Added enforceable Episode Boundary guardrails with configurable max event, duration, idle-gap, and trusted local-date limits, including best-effort decision audit rows that never roll back successful raw event assignment.
- Added read-only `cogmem episode audit-boundaries` / MCP `cogmem_episode_audit_boundaries` for bounded episode health diagnostics without Dream, repair, Atlas, binding, activation, or decision-audit writes.
- Added deterministic read-only `cogmem episode split-plan` / MCP `cogmem_episode_split_plan` previews that preserve logical turns and return `applyableInCurrentVersion=false` with no apply command.

## 3.7.2

- Fixed Memory Atlas `graph-explore` edge projection so selected action, topic, and ordinary memory edges are merged before the final stable edge limit.
- Added direct internal-edge SQL for selected Atlas nodes, including chunked parameters, so bounded graph results are not silently limited to the first 30 node IDs.
- Added edge truncation metadata and warnings when `graph-explore` omits candidate edges after prioritizing exact matched cards/facets.

## 3.7.1

- Hardened OpenClaw volatile recall, Atlas context, turn bridge, and session-state serialization so historical text, card titles, summaries, source windows, related cards, short-term conclusions, and source anchors cannot close or create `COGMEM_*` prompt blocks.
- Scoped entity facet node IDs by project, bumped the Atlas projection schema metadata, and forced old multi-facet projections to rebuild instead of reusing cross-project-prone entity nodes.
- Changed targeted `graph-reindex` to refresh the addressed episode/card but leave the project projection dirty until a full consistency rebuild restores relation/action-frame guarantees.
- Tightened Raw Ledger forensic anchor scope checks so event anchors cannot bypass project/workspace/thread/session boundaries.
- Fixed OpenClaw auto intent routing for `action_history`, exact-quote ranking for same-day raw events, issue-title precedence over generic operation titles, shared action-kind inference, stricter entity-plus-action compiled relevance, local-date year inference, and evidence-level Atlas card dedupe.
- Extended generic Atlas entity cue extraction to Unicode letter/number names in ordinary historical queries, and expanded explicit relaxation traces from day → month to day → month → year plus issue → parent topic.
- Updated OpenClaw plugin 0.7.1, docs, skills, and tests for the security/isolation hotfix.

## 3.7.0

- Upgraded Memory Atlas into a multi-dimensional navigation graph: canonical episodes and raw events exist once, while time, topic, issue, entity, session/thread, memory-kind, and action-kind facets connect to them with typed edges.
- Added deterministic episode title and one-line summary generation for Atlas cards, preserving the original long summary in metadata and marking low-confidence titles for review.
- Added facet query planning for day/month/year, topic, issue, and entity cues, including strict facet intersection, canonicalId dedupe, matched facet/path explanations, and explicit relaxation traces.
- Added agent-facing Atlas `cards[]` on graph search/explore with `displayTitle`, `oneLineSummary`, `canonicalId`, `matchedFacets`, `matchedPaths`, `relatedButNotSelected`, and source drill-down locators.
- Extended Atlas cards to timeline results and CLI recall JSON, shared relaxation behavior across graph search/explore/timeline, and made broad “记忆黑盒” recall select the initial Memory Context/sourceContext discussion while listing later graph/runtime and Atlas readability issues as related side context.
- Renamed the live Atlas projection to `memory_atlas.v2` with 3.7 schema metadata while still consuming legacy `memory_atlas.v1` dirty triggers, so upgraded 3.6.5 databases rebuild the multi-facet projection instead of trusting stale clean state.
- Integrated facet graph cards into `historical_discussion` recall so OpenClaw/Hermes agents can explain selected memories while still grounding answers in Raw Ledger source locators.
- Fixed action-history recall such as “what did I ask you to do to <entity>?” by adding operational action-kind facets (`started`, `installed`, `configured`, `restarted`, `stopped`, `operated`), inferred `action_history` routing, generic entity cue extraction, entity/action relevance gating for compiled memories, and raw-ledger-only exact quote fallback for “我的原话”.
- Added targeted `cogmem memory graph-reindex --project <id> --event <eventId>|--episode <episodeId> --json` and clearer episode repair output so `repairId` is treated as an audit id, not a dream promotion candidate.
- Updated OpenClaw plugin 0.7.0 and its generated bridge to preserve strict facet matches through Context Cortex planning and to include selected cards, matched facets/paths, related-but-not-selected side context, and relaxation traces in both volatile recall and Atlas context blocks.
- Updated README, Memory Atlas docs, OpenClaw/Hermes skills, AGENTS runbooks, and operations references with npm-first install/update flow and the 3.7.0 multi-facet Atlas command playbook.

## 3.6.5

- Added `cogmem memory plan` as a read-only agent operations summary with queue state, blocking/non-blocking next actions, Dream backlog hints, and vector fallback state.
- Made default `cogmem memory candidates --json` return grouped ordinary, `needs_confirmation`, and deferred queues with actionable `nextActions`, while explicit `--status` still lists one queue.
- Fixed `cogmem memory list --since/--until/--order` so raw-ledger inspection can resume from global sequence cursors instead of silently ignoring the filters.
- Added `sourceLocator` drill-down commands to raw ledger list rows and Atlas search/explore evidence so agents can move from summaries to exact `memory show` context before quoting or claiming absence.
- Added a `historical_discussion` recall intent for “did we discuss this before?” questions, with raw-ledger-first routing and expanded cues for Cogmem/OpenClaw memory-black-box discussions.
- Changed Memory Binding backfill to scan raw events by cursor across the historical ledger rather than only the latest page, so old imported high-value user events can be bound after upgrade.
- Changed `cogmem connect ... --json` to expose structured `nextSteps` and keep unsafe operator/host actions such as interactive init and host restart out of agent-safe `nextCommands`.
- Fixed `cogmem memory plan` so Raw Ledger dream coverage lag is reported as non-blocking `raw_dream_ledger_lag` with `resolvableByDreamTick:false` instead of misleading agents into looping `dream tick` when no sealed episode backlog exists.
- Updated the auto-installed OpenClaw/Hermes skills and operations handbooks with the full npm install, update, migration, import, `memory plan`, historical recall, source drill-down, governance, and maintenance command playbook.

## 3.6.4

- Fixed OpenClaw/Hermes imports so empty imported episode boundaries are not batch-sealed into Dream work, and mature empty soft seals no longer abort `dream tick`.
- Added Dream queue cleanup for legacy empty episode jobs so one bad upgraded/imported episode is marked skipped and does not consume maintenance batch slots.
- Updated OpenClaw and Hermes auto-installed skills, runbooks, and README examples to prefer npm workspace-local installs, reserve `cogmem init` for interactive operator setup, and document the full import -> dream -> candidate governance -> `needs_confirmation` review flow.
- Standardized MCP guidance on `cogmem mcp` for new Hermes/OpenClaw host configs while keeping `cogmem-mcp` as a compatibility bin for existing configs.

## 3.6.3

- Added a GitHub Release `published` workflow for npm Trusted Publishing with OIDC provenance, full tests, build, version-tag validation, and package dry-run verification before `npm publish`.
- Fixed `cogmem migrate --dry-run` so it opens SQLite read-only and plans legacy `_meta.schema_version` adoption without creating `_schema_migrations` or writing migration rows.
- Hardened `cogmem update` target resolution for npm global installs, one-line installer homes, local project dependencies, and source checkouts so `cogmem update --yes` does not silently install into an arbitrary current directory.
- Updated OpenClaw diagnostics and generated bridge behavior to propagate `rememberDrainTimeoutMs`, recover stale `.processing` queue files, and report pending/dead/lock/processing queue state.

## 3.6.2

- Switched the public distribution channel to the npm registry while keeping GitHub as the source and review mirror.
- Changed `cogmem update --yes` to install `cogmem@latest` from npm by default, then run post-install work through the newly installed local CLI.
- Added upgrade preflight and audit output for resolved config, backed-up migration command, OpenClaw plugin-only refresh command, skipped post-install reasons, and required agent restarts.
- Updated the one-line installer, release checklist, README, and installed OpenClaw/Hermes agent skill handbooks for npm install, one-command update, migration, import, repair, and restart workflows.

## 3.6.1

- Fixed OpenClaw upgrade regressions after 3.5.2 -> 3.6.0 by adding plugin-only repair/diagnose paths, generated-plugin hash inspection, and clearer `cogmem update` follow-up instructions.
- Upgraded the OpenClaw generated plugin to 0.6.2, fixed queued remember draining so the bridge passes the live kernel/backend into `rememberPayload`, and added stale queue-lock recovery plus bounded drain batches.
- Made the generated OpenClaw remember-queue drainer acquire the queue lock before loading Cogmem or opening SQLite, and debounced parent-side drainer spawning when a fresh queue/spawn lock already exists.
- Added richer `before_prompt_build` audit diagnostics, including bridge command, DB-lock detection, returned injection shape, context size, item count, and broader injection return compatibility fields.
- Added schema migration 27 and changed migration 26 so Atlas projections are dirty after upgrade until the real action/time projection rebuild runs.
- Let Atlas graph reads return existing projections with `atlasFresh=false` when refresh is blocked by SQLite busy, and added `--refresh`, `--no-refresh`, and `--stale-ok` graph CLI controls.
- Added `cogmem repair project-scope` for conservative empty-project upgrade residue repair, plus OpenClaw operations documentation for migration, plugin refresh, diagnose, and repair flows.

## 3.6.0

- Closed the `needs_confirmation` queue with audited CLI/MCP approve, reject, defer, supersede, and correction-relink actions. Use `cogmem memory candidates --status needs_confirmation`, then `cogmem memory review`; `govern --status needs_confirmation` now lists the queue and points operators at review instead of silently promoting the wrong status.
- Isolated `memory status` and `memory candidates` behind a lightweight read-only SQLite store, closed all kernel-owned handles deterministically, and added concurrent MCP/CLI coverage so routine inspection does not require stopping a long-lived agent host.
- Made Atlas facets exact and composable like table filters across project, time, topic, entity/target, memory kind, action, and text cues. CJK aliases, facet-only queries, multiple actions per event, raw tool/user actions, accumulated time evidence, weighted paths, and entity-specific timelines now remain source anchored.
- Removed Atlas popularity feedback from reads. Graph tools are read-only/idempotent; agents explicitly call `cogmem_graph_touch` only for nodes they use. Maintenance refreshes dirty projections only, records projection errors, cleans stale projects/access telemetry, and reports `evidenceTotal` separately from `evidenceReturned`.
- Unified OpenClaw Atlas exploration, evidence-bearing node/timeline drill-down, and normal recall in one bridge/kernel lifecycle. Injected Atlas context now includes evidence event IDs and exact drill-down commands.
- Added schema migration 26. A 3.5.2 schema-24 database, or a pre-release schema-25 test database, upgrades in one backed-up `cogmem migrate --yes --backup --json` run without rewriting Raw Ledger evidence.
- Upgraded the OpenClaw plugin to 0.6.1 and changed `cogmem connect` to install a full agent operations bundle. The installed skill now includes `references/operations.md` with command selection, migration, import, Atlas, review, repair, backup, evaluation, and non-overlapping maintenance guidance.

- Added Memory Atlas v1, a bounded, project-scoped content graph over existing topics, entities, clusters, episodes, beliefs, action frames, time buckets, relations, and exact raw-event evidence. It is canonical-memory-safe and records only non-evidentiary access/activation telemetry, not a second fact store.
- Added generic query-facet resurrection. Time, target/entity, topic, memory kind, and ordinary query cues work like combined table filters; exact scoped matches can surface cold memory without changing truth, confidence, ownership, or governance state.
- Added graph overview, search, explore, node, neighbors, path, and timeline APIs through the kernel, CLI, and canonical-memory-safe MCP tools. Read queries stay pure by default, explicit touch records selected-node use, and every evidence result carries an event ID plus a `cogmem memory show` drill-down command.
- Added deterministic Atlas activation and decay. Explicit touches raise visibility, maintenance decays it, and cold evidence remains recoverable through exact facets. Database triggers mark only changed projects dirty so normal queries do not rebuild the entire graph.
- Added OpenClaw direct graph exploration through the generated plugin bridge, with bounded volatile `COGMEM_MEMORY_ATLAS` context and no MCP requirement. Hermes receives the same graph surface through MCP.
- Standardized every documented CLI `--json` command on `cogmem.cli.v1`: object payload fields are available at the top level, arrays use `items`, and Dream/status queue counters have stable top-level aliases while legacy nested objects remain during the compatibility window.
- Added schema migration 25 with transaction-safe Atlas projection, action evidence, access/activation, FTS, and dirty-state tables. A 3.5.2 database upgrades with `cogmem migrate --yes --backup --json`; Raw Ledger evidence is preserved.
- Bumped the OpenClaw plugin to 0.6.0 and updated OpenClaw/Hermes skills and runbooks with graph-first navigation and exact-source drill-down rules.

## 3.5.2

- Added the user-shaped Memory Ontology and project-scoped topic path, alias, relation, and governance registries. Explicit user operations are active, audited, and reversible; model proposals stay candidates and alias collisions fail closed for review.
- Wired advisory hybrid classification into asynchronous assembly/import paths while preserving the CPU-only foreground hook. Unknown turns now default to ambiguous review, reviewer fields are allow-listed, assistant context distinguishes proposal acceptance from question/fact answers, and unsafe soft-seal reopen paths are blocked.
- Hardened episode Dream evidence and ownership: invalid provider evidence is rejected without fallback, CPU project scope wins, assistant-only decisions and orphan corrections require confirmation, proposal confirmation uses bounded same-thread history, and summaries remain non-evidence hints.
- Added per-job Dream modes, deep recommendations, persisted per-episode failure diagnostics, multi-action episode status, and hookless recall freshness warnings.
- Added resumable CLI/MCP import diagnostics, ingest-key lifecycle state, source-agent identity validation, and unified asynchronous episode assembly for source imports.
- Added audited episode split, merge, move-event, reclassify, and Dream requeue/invalidation surgery with closure recomputation, cross-references, stale-candidate invalidation, and Dream requeue.
- Added shared malformed `COGMEM_*` block stripping, payload text allow-listing, schema migration 24/parity coverage, new BrainEval reliability gates, OpenClaw plugin 0.5.0, and updated OpenClaw/Hermes agent skills.

## 3.5.1

- Hardened Episode classification with previous assistant/user context, explicit assistant-side relations, confidence and audit signals, safe subtopic/ambiguous/hard switch handling, and an advisory-only hybrid review API that cannot write memory.
- Added non-evidence semantic episode summaries, multi-tag importance metadata, normalized closure reasons, source/thread-scoped active lookup with legacy upgrade fallback, and separate episode/Dream lifecycle state.
- Made micro, normal, and deep Dream modes change curator scope and candidate limits; added retryable, scheduled, and terminal failure states with backoff and episode-level error visibility.
- Enforced raw-event evidence subsets for episode candidates, paired assistant-proposal/user-confirmation evidence, orphan-correction review, decision temporal candidates, and existing prospective-memory deduplication boundaries.
- Replaced line-index import identity with stable source/session/role/time/content identity; added streaming JSONL checkpoints, resume support, confidence-aware batch sealing, and bounded MCP imports.
- Guarded MCP `cogmem_dream_tick` behind `maintenanceMode: true`, enriched hookless-agent status guidance, added schema migration 23, and updated OpenClaw plugin 0.4.1 plus OpenClaw/Hermes skills.

## 3.5.0

- Added Episode Dream Engine v1. Raw messages are still written immediately, while deterministic session-scoped episode assembly gives Dream a bounded conversation-level unit instead of an arbitrary raw-event window.
- Added auditable open, soft-sealed, and sealed episode lifecycle, closure receipts, safe soft reopen, hard-seal protection, one-event-one-episode assignment, repair of unassigned raw evidence, and project-scoped forget cleanup.
- Added conditional `cogmem dream tick`: timers now wake a scheduler that chooses no work, micro, normal, or deep processing from the sealed backlog. Recall and OpenClaw foreground hooks never run Dream.
- Added leased, retryable, idempotent episode Dream jobs and run receipts. Every episode-derived candidate retains `sourceEpisodeId` plus exact raw event evidence and still requires existing CPU governance.
- Scoped message import idempotency to project, source agent, and source session; conflicting reuse is rejected, reserved identities can recover a missing Raw Ledger write, and exhausted Dream leases remain explicitly retryable.
- Added `cogmem episode` and `cogmem dream` CLIs plus bounded MCP episode append/import/status/seal and Dream tick/status tools for hookless Hermes-style agents.
- Unified existing OpenClaw/Hermes imports and live turn recording behind the same episode schema, with explicit batch sealing and duplicate-message protection.
- Added BrainEval episode grouping, boundary, evidence coverage, unassigned rate, candidate grounding, governance bypass, and Hermes import parity gates.
- Updated OpenClaw auto-memory plugin to 0.4.0, Hermes MCP allow-list repair, schema migration 22, package migration/update docs, and all agent-facing skills for the episode-first workflow.

## 3.4.0

- Added Strategy Cortex v1: deterministic current-turn strategy capsules select retrieval lanes, context-layer order, exact-source requirements, and bounded memory budgets before recall.
- Added one-retry deterministic replanning for intent/project changes, unmet source requirements, evidence conflict, and unsatisfied required-layer budgets. No online RL or multi-strategy generation is used.
- Added `COGMEM_STRATEGY_CONTEXT` with no instruction authority and full OpenClaw/Dream/Binding/reasoning-model hygiene so strategy metadata cannot become user evidence or durable memory.
- Added read-only `MemoryUseJudge`, project-scoped context outcome telemetry, offline diverse strategy selection, rollout comparison, and zero-tolerance context policy release gates.
- Added `cogmem strategy plan/outcomes`, `cogmem brain-eval --strategy-rollout` for precomputed offline outcomes, and read-only MCP `cogmem_strategy_plan` for agent inspection.
- Updated OpenClaw auto-memory plugin to 0.3.0 and Hermes MCP allow-list patching for `cogmem_strategy_plan`.
- Added schema migration 21 and extended `forgetUser(projectId)` to purge strategy outcome telemetry.
- Strategy/action separation is inspired by StraTA; Cogmem intentionally keeps online planning deterministic and performs multi-strategy comparison only on precomputed offline outcomes.

## 3.3.0

- Added confirmed-only Prospective Memory for intentions, commitments, reminders, open loops, and plans. Rejected items require new evidence to create a new version, and no execution/dispatch API exists.
- Added `cogmem prospective` candidate-state CLI and `cogmem brain-eval` safety/quality release gate.
- Added `cogmem_prospective` MCP state management with explicit project boundaries and distinct user confirmation evidence; it exposes no execution path.
- Added BrainEval metrics for recall, precision, provenance, budget compliance, stale/cross-project leakage, and unconfirmed prospective activation.
- Added schema migration 20 and completed the 2.8.0-3.3.0 cumulative migration path.
- Made migration backups transaction-consistent and WAL-aware through SQLite's native backup path.
- Extended `forgetUser(projectId)` across governance, entity, belief, temporal, context-receipt, and prospective projections, including shared canonical-alias rebuilding.
- Changed `cogmem update` to fail closed when GitHub has no latest-release metadata instead of silently installing mutable `main`.

## 3.2.0

- Added Context Cortex intent, safety suppression, layer activation, source-first drill-down, and a 25% default/30% maximum memory budget.
- Added persistent activation receipts that explain selected and suppressed memory IDs and reasons.
- Updated OpenClaw auto-memory plugin to 0.2.0: greetings skip memory, short continuations use only session state/turn bridge, and full recall is Cortex-filtered.
- Added schema migration 19.

## 3.1.0

- Added validity-window belief lookup and bounded project/entity timelines for milestones, decisions, corrections, and belief versions.
- Preserved correction reasons, evidence anchors, and supersession history while keeping current-state queries free of stale versions.
- Added schema migration 18 and public `TemporalMemoryService` access through `MemoryKernel`.

## 3.0.0

- Added an evidence-backed Belief Graph with ownership, versions, source roles, conflict records, and supersession chains.
- Enforced explicit user evidence for user-owned preferences, goals, boundaries, decisions, and facts; assistant/tool-only evidence is limited to project observations.
- Added deterministic reinforcement, correction, and contradiction behavior plus schema migration 17.

## 2.9.0

- Added evidence-backed, project-scoped entity merge candidates with stricter explicit-user-evidence requirements for person entities.
- Made entity merges reversible through alias, redirect, archive, and resolution-log operations; source entities are never destructively deleted.
- Unified Memory Binding entity IDs with canonical `EntityStore` identity and added schema migration 16.

## 2.8.0

- Added evidence-backed `MemoryGovernancePlan`, strict CPU validation, idempotency keys, project and ownership checks, transactional execution, and audit records. Missing raw evidence and assistant/tool-only user-owned memory are rejected before persistence.
- Added Memory Binding v1.5 primitives: `TopicPathRegistry`, `ClaimKeyGenerator`, `BindingDecisionEngine`, activation-aware weighted edges, and bounded read-only `BrainGraphView` traversal.
- Split graph edge confidence, stability, and activation so maintenance decay affects memory surfacing rather than historical truth or provenance.
- Added schema version 15 and `cogmem migrate` with dry-run, legacy schema adoption, idempotent migration tracking, and optional pre-migration database backup.
- Changed `cogmem update --yes` to resolve GitHub Releases, install the selected release, and invoke the newly installed schema migration command with backup enabled.

## 2.7.1

- Fixed OpenClaw Markdown role-boundary parsing for empty `user:` / `assistant:` headers with multiline bodies, preventing assistant self-correction text from being attached to the preceding user event. Adjacent exact duplicate exports are collapsed with an import diagnostic while non-adjacent repeats remain chronological evidence.
- Preserved source chronology from OpenClaw headings such as `# Session: 2026-06-06 14:00:43 UTC`; imported turns now use the session start as their ordered timestamp base instead of the downloaded file mtime.
- Changed Dream correction handling so explicit user clarifications become promoted organizational `correction` records instead of false `contradictions`; negative-form questions such as `是不是...` do not trigger correction classification. Assistant self-correction remains conversational evidence and cannot create a user-owned correction.
- Tightened model-proposed conflict candidates: they now require two or more distinct, exact raw event IDs from the current Dream window. Hallucinated IDs and `evidenceEventIds: ["all"]` are rejected instead of being rebound to unrelated window evidence.
- Rejected malformed memory-model output as observable non-fatal provider diagnostics instead of adding queue garbage to `needs_confirmation`; later successful provider runs supersede the diagnostic audit record.
- Added auditable review-queue aging to host-owned maintenance ticks. The default 30-day TTL marks stale `needs_confirmation` candidates `superseded` with a status reason while preserving all evidence rows.
- Added `agent_recall_decision.v1` traces to API, CLI, MCP, explain-recall, OpenClaw audit output, and volatile prompt context. Agent-scoped explain-recall now uses the same selected evidence path as normal agent recall.
- Fixed raw-ledger fallback so Chinese/non-FTS text recovery searches the fully scoped ledger instead of only a recent fixed window. Equal raw cue matches prefer the original user event, and past-memory queries prefer a cue-matching raw user anchor over a compiled assistant retelling.
- Bumped the core schema to version 14 for deep-write candidate `status_reason` and `updated_at` lifecycle metadata.

## 2.7.0

- Added Memory Binding v0: high-value user raw events are now deterministically bound to stable topic/entity paths such as `PROJECT/Cogmem/memory-write-pipeline` during agent turn recording. Bindings are source-anchored organization hints, not promoted facts or beliefs.
- Added Historical Binding, Cluster Fusion, and Graph Recall v1 on top of Memory Binding: same-topic user events now strengthen fused clusters, correction events create review-flagged correction clusters, and agent recall can follow binding graph anchors back to raw ledger evidence before falling back to vector/FTS paths.
- Added Graph Recall v1.1 stabilization: deterministic `BindingClassifier`, project alias/topic keyword routing, claim-key cluster IDs to avoid over-fusion, explicit `CORRECTS`/`CONTRADICTS` correction edges, query-aware graph anchor ranking, observable non-fatal binding failures, `cogmem memory bind` backfill for imported/raw events, and schema version 13 for binding sidecar tables.
- Added `MemoryKernel.listMemoryBindings()`, `MemoryKernel.listMemoryClusters()`, `MemoryKernel.listMemoryEdges()`, `MemoryKernel.bindRawEvents()`, `MemoryKernel.recallMemoryBindingGraph()`, and memory-map counters for binding, topic, entity, cluster, and edge organization so agents can inspect where important raw events are attached before relying on long-term compiled memory.
- Fixed `MemoryKernel.forgetUser(projectId)` to purge durable activation hotspots and memory bindings for the forgotten project, preventing stale memory-map and maintenance-tick exposure.
- Fixed `cogmem connect hermes --auto` so existing Hermes `cogmem-mcp` entries are updated with missing `cogmem_memory_map` and `cogmem_maintenance_tick` tool allow-list entries.
- Reviewed the bounded reasoning, tool schema, and Dream Curator prompt changes: Cogmem recall blocks, turn bridges, and session state remain evidence-only and cannot create durable user memory without explicit user evidence and CPU governance.

## 2.5.0

- Added explicit collection routing for agent recall so operational memory remains the default path while creative artifacts such as `collection:theseus` must be requested intentionally.
- Added `cogmem memory map` / MCP `cogmem_memory_map` for agent and host self-inspection of raw ledger, compiled memory, recall routes, maintenance surfaces, and safety bounds.
- Added `cogmem memory tick` / MCP `cogmem_maintenance_tick` for host-owned maintenance ticks with activation decay and upkeep suggestions, without starting hidden daemons.
- Added OpenClaw context hygiene safeguards: volatile `<COGMEM_RECALL_CONTEXT>`, compact `<COGMEM_TURN_BRIDGE>`, session-only `<COGMEM_SESSION_STATE>`, recall-block stripping before remember, user-only `selective_compile` signals, and current-session compiled-memory exclusion.
- Added labeled source-context replay metadata. Agent-facing `sourceContext` and `cogmem memory show --json` now expose per-event `label`, `textLength`, optional `charRange` / `sourceRange`, and strict before/after `window` metadata with anchor exclusion, chronological ordering, role filter, and overlap handling.
- Changed OpenClaw automatic memory injection to render `sourceWindow`, labeled `sourceBefore` / `sourceAfter`, and `sourceTruncation` metadata so agents can cross-reference injected memory with raw ledger drill-down before quoting exact text.
- Added raw source position propagation from imported source refs into raw ledger events when source offset, line range, or character range is available.

## 2.0.0

- Split the memory kernel into an independently installable core package for GitHub source distribution.
- Added a stable Cogmem home directory with TOML configuration at `~/.cogmem/config.toml`.
- Added `core.vector_dimension` for TOML-based embedding dimension configuration, including high-dimension warnings.
- Removed legacy env-file/global-env configuration entrypoints; TOML is now the only supported configuration surface.
- Added `cogmem init` and `cogmem doctor` for first-run setup and validation.
- Added `cogmem import-openclaw` and `cogmem import-hermes` for command-triggered migration from existing agent workspaces.
- Added `KernelAgentMemoryBackend` for external agent integrations.
- Routed `KernelAgentMemoryBackend.recall()` through universe navigation by default, with BrainRecall retained as fallback.
- Exported the pulse/universe retrieval orchestrators for advanced agent integrations.
- Added core-native OpenClaw and Hermes workspace profiles.
- Added agent-facing OpenClaw and Hermes runbooks under `examples/*-backend/AGENTS.md`.
- Added snapshot, vector backend, governance, PII redaction, and encryption release hardening.
- Added a GitHub-only release checklist; `npm pack --dry-run` is used for artifact verification, not npm publishing.
- Added Chronological Memory Ledger helpers for raw event replay, source anchors, sourceRefs, and recall explanation drill-down.
- Added JSON/JSONL/CSV/TSV normalization source anchors and agent lifecycle facade methods for tool calls, tool observations, and task events.
- Added `cogmem-normalize-transcript` for dry-run friendly transcript normalization into source-ref Markdown before import.
- Added `memory_natural_emergence` benchmark baselines for critical recall, old-important recall, stale/superseded/suspect leakage, cross-project leakage, provenance completeness, context budget efficiency, pulse expansion, and inhibition correctness.
- Added the unified `cogmem` CLI, `cogmem update`, `cogmem connect openclaw --auto`, and `cogmem doctor --fix --agent openclaw` so OpenClaw can install/repair an automatic recall and turn-recording wrapper without hand-editing runtime files.
- Added selective agent turn ingestion modes so OpenClaw/Hermes can preserve raw ledger evidence without embedding every conversation turn.
- Added raw ledger FTS search through `MemoryKernel.searchRawEvents()` for source discovery and cold recall without requiring per-sentence vectors.
- Added bounded agent-facing `raw_ledger_fallback` after governed compiled recall misses.
- Added dream backlog status helpers for `raw_then_dream` coverage tracking.
- Added `cogmem compact` and `cogmem doctor --storage` for vector-only storage diagnostics and safe compaction.
- Changed the OpenClaw automatic memory wrapper to queue `agent_end` remember jobs and drain them in the background, avoiding synchronous response blocking from slow embeddings or SQLite writes.
- Added best-effort OpenClaw lifecycle capture for tool calls, tool results, and task events when the host hook payload exposes them.
- Added operational noise suppression so heartbeat polls, `HEARTBEAT_OK`, and setup reminders remain auditable evidence but do not enter active agent context by default.
- Added session-aware and forensic recall intents for `KernelAgentMemoryBackend` and the OpenClaw auto-memory wrapper, separating current conversation context from retrieved history and requiring raw ledger anchors for exact wording.
- Added `compileAgentRecallQuery()` and `queryPlan` output for `KernelAgentMemoryBackend.recall()`, so long natural-language memory questions are distilled into bounded recall cues before semantic and raw-ledger lookup.
- Added forensic follow-up anchors (`anchorEventId` / `anchorText`) so adapters can answer "what were my exact words" from the previous raw source event instead of guessing from a vague query or imported summary.
- Added `cogmem memory` / `cogmem-memory` as a local audit console for status, raw ledger listing, raw text search, and event context drill-down.
- Added `MemoryKernel.runDreamCurator()` and `listDreamCandidates()` plus `cogmem memory dream` / `cogmem memory candidates` so `raw_then_dream` produces source-anchored candidate memories and an auditable governance queue without creating vectors or verified facts.
- Added explicit Memory Curator / Dream Worker model support through the existing TOML `[memory_model]` OpenAI-compatible role, including local Ollama or cloud endpoints. Model output is normalized into candidate-only governance records for user preferences, project memories, long-term goals, boundaries, failure lessons, diagnostics, summaries, temporal updates, and conflicts.
- Added dream curator schedule helpers for host-owned `manual`, `interval`, `daily`, and `continuous` workflows without starting a hidden core daemon.
- Added `semanticCuePhrases`, `temporalHints`, and `sourceContext` to agent-facing recall so wording-drift questions such as `记忆黑盒` can find older `存档位置属于黑盒` raw evidence and agents can drill down to exact raw ledger context.
- Added raw ledger anchors for imported OpenClaw/Hermes records so legacy memory files remain searchable through `cogmem memory search/show/recall` after curation while imported summaries stay `canAnswerExactQuote=false`.
- Added `cogmem import-openclaw --reindex-raw` / `cogmem import-hermes --reindex-raw` to backfill raw ledger anchors for records imported by older versions without duplicating compiled memory or hot vectors.
- Added `cogmem memory recall` as an agent-facing active memory search command using `KernelAgentMemoryBackend.recall()` with query plans and source context, so OpenClaw can query CogMem when automatic prompt injection is empty.
- Expanded the Memory Curator / Dream Worker with semantic tag, indexing decision, semantic relation, and edge-adjustment candidates for host-owned curation loops without directly mutating verified memory.
- Added `cogmem memory govern`, `cogmem memory dream --promote`, and `cogmem memory dream --watch` so hosts can run a supervised curation/governance loop without cron-only polling or unbounded candidate backlog.
- Added `KernelAgentMemoryBackend.recallPack()` with direct recall, associative graph/activation neighbors, entity cards, belief touches, and a charge vector for pre-answer agent context assembly.
- Added persistent activation tracking plus `MemoryKernel.runMaintenanceTick()` and `cogmem memory tick` for explicit host-owned upkeep suggestions without starting a hidden daemon.
- Added `MemoryKernel.buildMemoryMap()` and `cogmem memory map` so agents and hosts can inspect memory anatomy, data lanes, hard bounds, counters, and recommended commands.
- Added collection routing via `collection:<name>` tags and `--collection`, keeping `collection:theseus` creative artifacts out of default operational recall unless requested explicitly.
- Added MCP `collection` support for `cogmem_remember_turn`, `cogmem_recall`, and `cogmem_explain_recall`, plus new `cogmem_memory_map` and `cogmem_maintenance_tick` tools.
- Added CPU promotion handling for source-anchored summaries/preferences and semantic organization candidates while keeping uncertain claims in `needs_confirmation` and never upgrading them to verified facts automatically.
- Deduplicated Dream Curator provider warnings and supersede stale provider diagnostics after a later successful structured memory-model run.
- Added Hermes `state.db` import support for SQLite `messages` history, including explicit `--state-db`, automatic workspace-root discovery, source-anchored raw ledger records, and message timestamp precedence over `InsertTime`.
- Added Hermes JSONL session-export normalization for one-session-per-line objects with `messages[]`.
- Fixed semantic relation candidates so promoted records keep a readable `content.summary` instead of empty organization metadata.
- Fixed agent-facing raw fallback recall to retry host-neutral keyword cues and avoid returning duplicate user/assistant events from the same turn.
- Fixed the one-line installer so `curl | bash` starts `cogmem init` from `/dev/tty` instead of consuming an exhausted pipe.
- Fixed `cogmem update` so `latest` dynamically resolves the GitHub latest release payload instead of fabricating a nonexistent `releases/latest/download/cogmem.tgz` package URL.
- Fixed Hermes active recall when `vectors=0` by letting agent-facing recall fall back to source-anchored raw ledger evidence for imported Hermes records instead of filtering them out by source id.
- Fixed agent-facing recall quality when universe navigation returns non-matching compiled candidates by preferring raw ledger cue matches; inventory queries now expand into structured cues such as `库存管理`, `在库`, `产品コード`, and `数量`.
- Fixed MCP `cogmem_recall` to use the same agent-facing recall backend as `cogmem memory recall`, so project-only Hermes calls can return raw ledger fallback items with `sourceContext` instead of empty `items` when compiled evidence or vectors are absent.
- Fixed `cogmem memory status --json` to expose stable top-level `rawEvents`, `vectors`, `dreamedRawCount`, `undreamedRawCount`, and `dreamCoverageRate` fields.
- Fixed Hermes `state.db` and JSONL transcript timestamp handling for numeric epoch-second message timestamps, and added WAL-mode SQLite immutable read fallback for `state.db`.
