# Contributing

## Setup

`dist/` is not tracked (#53), so a source checkout must be built before anything that reads build
output — the OpenClaw plugin installer falls back to `dist/public.js`, and the test gate runs after
the build.

```bash
bun install
bun run build
bun run typecheck
bun test
```

## Pull Request Gate

Before opening a pull request that changes core, run:

```bash
bun run build
bun run typecheck
bun test
npm pack --dry-run --json
```

`cogmem` is distributed through the npm registry. **This is not the PR gate.** Publishing is the point of no return for a version, and the 4.0 line is unreleased by decision (AGENTS.md): a tag creates a GitHub Release whose `published` event publishes to npm, so nothing here should be run until the owner says so. Use `npm pack --dry-run --json` to verify package contents. Normal publishing happens by creating a GitHub Release from the matching version tag; `.github/workflows/publish.yml` is intentionally triggered by the release `published` event, not by tag pushes. Use `npm publish --provenance --access public` only as an emergency manual fallback.

## API Discipline

Only explicitly exported symbols in `src/public.ts` are public. Do not re-export `src/internal.ts` from the package entrypoint.

## Adapter Changes

Agent-specific adapters must keep core independent from host runtimes. Prefer a narrow workspace profile plus fixture-backed tests over importing another runtime.
