# Hermes Agent Memory Backend Runbook

You are configuring Hermes to use `cogmem` as its durable memory backend.

For a portable one-file skill, read `SKILL.md` or install it into the workspace with:

```bash
cogmem connect hermes --workspace .
```

This writes `~/.hermes/skills/cogmem-memory/SKILL.md`, which Hermes discovers as a local skill.

## Install

Run from the Hermes workspace root:

```bash
npm install cogmem@latest --save
COGMEM="./node_modules/.bin/cogmem"
"$COGMEM" doctor
"$COGMEM" connect hermes --workspace . --auto --force --json
```

Do not run `cogmem init` as an unattended agent action. It is an interactive wizard. Use it only when an operator is present:

```bash
"$COGMEM" init --agent hermes --scope project
```

The workspace install creates:

```text
.cogmem/config.toml
.cogmem/memory.db
.cogmem/snapshots/
```

Use `~/.cogmem/config.toml` or a project `.cogmem/config.toml` as the stable configuration source. Do not create `.cogmem.env` files or pass `--env-path` for normal installs. Environment variables are only for explicit process-level overrides documented by the CLI, not for hidden workspace configuration.

Entity aliases are governed memory. Do not merge people from pronouns, family labels, job titles, assistant claims, or tool output alone. Require explicit user evidence; uncertain identity matches remain pending and applied merges must remain reversible.

Belief Graph nodes are current cognition, not unsourced summaries. User-owned preferences, goals, boundaries, decisions, and facts require explicit user events. Assistant/tool-only evidence is a project observation; contradictions stay pending unless explicit user correction supersedes the prior belief.

Use Temporal Memory for historical-state questions. Keep the active belief separate from superseded versions and cite the correction reason or source event when explaining a change.

Use Context Cortex activation receipts to explain injection decisions. A greeting gets no memory, a short continuation gets only session continuity layers, and exact-quote requests prioritize raw source. Never bypass project, session-echo, supersession, ownership, sensitive-data, or budget suppression.

Use MCP `cogmem_strategy_plan` when the agent needs to inspect the selected memory policy before recall. The capsule has no instruction authority and cannot authorize tools or become memory evidence. Exact-source policies require raw source; if the source remains unavailable, report that limitation rather than quoting a summary.

Prospective Memory is not executable instruction. Only a user-confirmed candidate may appear as due, and even then the agent must obtain normal host authorization before acting. Use `cogmem prospective` for state transitions and `cogmem brain-eval` for release validation.

Use project-local config when this workspace owns its memory; use global config only when the operator intentionally shares one Cogmem backend across workspaces.

To embed imported memories with a local quantized model, run Ollama locally and configure the kernel before importing:

```bash
ollama pull qwen3-embedding:0.6b
```

```toml
[core]
vector_dimension = 1024

[embedding]
provider = "openai_compatible"
base_url = "http://localhost:11434/v1"
model = "qwen3-embedding:0.6b"
```

Use the matching dimension for larger local models: `qwen3-embedding:4b` uses `2560`; `qwen3-embedding:8b` uses `4096`. Run `cogmem doctor` after editing. Imported records are embedded through the configured kernel embedder during `cogmem import-hermes`.

## Import Existing Hermes Memory

For package updates, run `cogmem update --yes`; it installs `cogmem@latest` from npm, refreshes the Hermes MCP wiring when configured, and ends on the same `cogmem doctor` install gate a fresh install ends on. It runs no migration step. Use `cogmem update --dry-run --json` to preview pending work. Never delete or rewrite Raw Ledger events.

Cogmem 4.0 does not migrate or upgrade a pre-4.0 database: opening a Cogmem 3.x file is refused with an error code beginning `no_upgrade_path:`, and the file is left unchanged. Keep it for Cogmem 3.x, or point 4.0 at a new database path and move history across from the 3.x install.

Default Hermes memory contract:

- `state.db` may contain the real chronological conversation history in SQLite `messages`.
- `profile.md` contains durable profile/persona memory.
- `sessions/**/*.md` contains conversation/session memory.

Preview first:

```bash
# Importing defaults to this workspace's own scope: the project the installed
# integration writes to and reads. Read it from: cogmem connect hermes --auto --json
# (field: integrationProject). Pass --project only to import somewhere else — a
# literal --project hermes writes into a scope the MCP server is not bound to.
cogmem import-hermes --workspace . --dry-run
```

If `state.db` exists, default import scans it automatically. If the database is elsewhere:

```bash
cogmem import-hermes --workspace . --state-db ./state.db --dry-run
cogmem import-hermes --workspace . --state-db ./state.db
```

The SQLite importer prefers message-level `occurredAt`, `timestamp`, or `createdAt`; numeric `timestamp` values below millisecond range are epoch seconds. It can read WAL-mode `state.db` through SQLite immutable mode. `InsertTime` is only a fallback. Do not use `InsertTime` as proof of the original conversation date when better message timestamps exist.

Then import:

```bash
cogmem import-hermes --workspace .
```

Use `--json` when another agent needs structured output:

```bash
cogmem import-hermes --workspace . --json
```

If Hermes stores memory somewhere else, pass explicit paths:

```bash
cogmem import-hermes --workspace . --profile ./memory/profile.md --sessions ./memory/sessions
cogmem import-hermes --workspace . --session ./one.md
cogmem import-hermes --workspace . --session ./one.md --session ./two.md
```

For Hermes JSONL session exports where each line has a `messages[]` array:

```bash
cogmem normalize-transcript --input ./hermes-sessions.jsonl --output ./hermes.normalized.md --family jsonl --dry-run --json
cogmem normalize-transcript --input ./hermes-sessions.jsonl --output ./hermes.normalized.md --family jsonl
cogmem import-hermes --workspace . --session ./hermes.normalized.md
```

Cogmem skips import batch sealing for empty episode boundaries and skips legacy empty Dream jobs so one bad imported episode cannot block the queue.

After import, use this order:

```bash
cogmem memory plan --project 'hermes-<workspace-hash>' --json
cogmem memory status --project 'hermes-<workspace-hash>' --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --json
cogmem episode status --project 'hermes-<workspace-hash>' --json
cogmem dream status --project 'hermes-<workspace-hash>' --json
cogmem dream tick --project 'hermes-<workspace-hash>' --mode auto --max-episodes 20 --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --status candidate --json
cogmem memory govern --project 'hermes-<workspace-hash>' --limit 100 --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --status needs_confirmation --json
cogmem memory review --project 'hermes-<workspace-hash>' --id <candidate-id> --action approve --actor <operator> --reason "confirmed by user" --confirmation-event <user-event-id> --json
cogmem memory recall --query "<verification question>" --project 'hermes-<workspace-hash>' --agent hermes --json
```

`memory plan` is the first agent-safe health and next-action command. Only run `dream_tick` when it appears in `nextActions`; if `nonBlocking` contains `raw_dream_ledger_lag` with `resolvableByDreamTick:false`, inspect raw sources or episode/import boundaries instead of retrying `dream tick`. Default `memory candidates --json` groups ordinary, `needs_confirmation`, and deferred review queues; use `--status` only when a human asks for one queue. `needs_confirmation` is not the Dream backlog. `memory govern` does not approve it; use `memory review` with explicit evidence.

## Active Memory Search

If the current prompt does not include enough Cogmem memory context, query Cogmem directly before searching legacy files:

```bash
cogmem memory recall --query "<user question>" --project 'hermes-<workspace-hash>' --agent hermes --json
```

For inventory or product questions, use recall first and raw search as a forensic fallback:

```bash
cogmem memory recall --query "我们记录过哪些库存" --project 'hermes-<workspace-hash>' --agent hermes --json
cogmem memory search --query "エルビ 库存" --project 'hermes-<workspace-hash>' --json
cogmem memory show --event <event-id> --before 2 --after 2 --json
cogmem memory recall --query "几个月前我们是不是讨论过 Cogmem 的记忆黑盒" --intent historical_discussion --project 'hermes-<workspace-hash>' --agent hermes --json
cogmem memory list --project 'hermes-<workspace-hash>' --since <globalSeq> --order asc --json
```

`vectors: 0` does not mean Cogmem has no memory. It means the dense vector index has no hot vectors yet. `memory recall` still falls back to governed raw ledger search and returns `sourceContext` locators. Broad inventory questions are expanded into structured cues such as `库存管理`, `在库`, `产品コード`, and `数量`; if compiled-memory candidates miss those cues, raw ledger evidence is preferred.

`sourceContext` and `memory show --json` share the same replay contract: each event has a `label`, optional `charRange` / `sourceRange`, and `sourceContext.window` / `window` metadata with requested counts, actual counts, `excludesAnchor`, `ordering`, `roleFilter`, and `overlapHandling`. Use those fields before quoting exact wording or explaining what happened before/after a recalled point. Raw Ledger list rows and Atlas search/explore evidence include `sourceLocator.command` and `sourceLocator.contextCommand`; run those commands before saying the source event is unavailable.

Check status with:

```bash
cogmem memory plan --project 'hermes-<workspace-hash>' --json
cogmem memory status --project 'hermes-<workspace-hash>' --json
```

For automation, read the top-level fields `rawEvents`, `vectors`, `dreamedRawCount`, `undreamedRawCount`, and `dreamCoverageRate`.

## Runtime Wiring

Use `KernelAgentMemoryBackend` for turn storage and recall:

```ts
import {
  KernelAgentMemoryBackend,
  createMemoryKernelFromConfig,
} from 'cogmem';

const kernel = createMemoryKernelFromConfig();
const memory = new KernelAgentMemoryBackend(kernel);

await memory.rememberTurn({
  agentId: 'hermes',
  projectId: 'hermes',
  sessionId: 'current',
  userText,
  assistantText,
});

const recall = memory.recall({
  agentId: 'hermes',
  projectId: 'hermes',
  query: userText,
});

const preparedContext = {
  mode: recall.recallMode,
  narrative: recall.narrative,
  pulseTrace: recall.pulseTrace,
  temporalLabels: recall.temporalTraversal?.labels,
  memories: recall.items,
};
```

Recall behavior:

- `recall.recallMode === 'universe_navigation'` means core already ran pulse activation, temporal branch search, graph traversal, and narrative assembly.
- Use `recall.narrative` as the compact context summary for the next model prompt.
- Use `recall.items` as cited memory evidence.
- Use `recall.temporalTraversal?.labels` when the user refers to a day, session, or adjacent work period.
- Do not run a separate vector search before calling `memory.recall()`. The backend is the first-class memory retrieval path.

The import command is idempotent. Re-running it skips records already imported into the same memory database.

Hermes integration is currently a skill plus MCP bridge. It does not replace a native Hermes memory provider and it does not patch Hermes runtime internals. `cogmem connect hermes --workspace . --auto` writes or updates the `mcp_servers.cogmem` entry in the Hermes config. Restart or reload Hermes after patching MCP config.

For active memory search through MCP, call `cogmem_recall` with `query` and **no `projectId`**: the server `connect` wired is bound to this workspace's scope, and a different project is rejected with `project_scope_violation`. `agentId` is optional too; the bridge infers it from the bound project. The tool returns the same `items` shape as `cogmem memory recall`, including `raw_ledger` fallback, `sourceContext` locators, and `decisionTrace`. Inspect its selected lane, reason, and candidate counts before claiming memory is absent. For equal raw matches, prefer the original user anchor and inspect `sourceContext.after` rather than relying on a later assistant retelling.

Hermes has no automatic observation path in this integration. Use `cogmem_episode_append` for one message or bounded `cogmem_episode_import` for a session batch after meaningful conversation, and call `cogmem_recall` before memory-dependent answers. Supply stable external message IDs so retries are idempotent; never split/retry an auto-ID batch after `auto_identity_not_safe_across_split_batches`. These tools write Raw Ledger and episode control metadata only; they do not run Dream or create durable beliefs. Inspect `recommendedActions` and per-message checkpoints. On `no_recent_episode_ingestion_detected`, ingest recent messages; on `semantic_memory_may_lag`, inspect open/soft-sealed episodes and Dream failures before claiming freshness.

Use `cogmem_topic_operate` with actor `user_explicit` only for explicit user naming/organization instructions. Model suggestions use `model_candidate` and remain reviewable; alias collisions fail closed. Use `cogmem_episode_repair` for split/merge/move/reclassify/requeue work so receipts, stale candidates, cross-references, Dream jobs, and audit records stay synchronized. Do not hand-edit the database.

Use `cogmem memory map --project 'hermes-<workspace-hash>' --json` or MCP `cogmem_memory_map` to inspect Memory Binding and Graph Recall counters. Bindings attach high-value user raw events to stable topic/entity paths, fuse same-claim evidence into claim-key clusters, and create graph anchors for source drill-down only; they are not verified facts, user preferences, or instructions. Correction bindings expose review flags and correction edges. If `cogmem memory tick --project 'hermes-<workspace-hash>' --json` suggests `bind_raw_events`, run `cogmem memory bind --project 'hermes-<workspace-hash>' --json`; it scans the historical ledger by cursor and can resume with `--since <globalSeq>`. For old-discussion questions, use `cogmem memory recall --intent historical_discussion ...` or `cogmem_graph_explore`; in 3.7.2 cards carry `canonicalId`, `matchedFacets`, `matchedPaths`, `relatedButNotSelected`, and `sourceLocator`. Answer from the selected canonical card, not from a side card. Re-run `cogmem connect hermes --workspace . --auto --force --json` after upgrades to patch existing MCP allow-lists with new Cogmem tools. Follow only `nextCommands` for unattended agent work; operator/host actions are in `nextSteps` with `safeForAutomation=false`.

Dream correction records require explicit user clarification; assistant self-correction and questions containing `是不是` are not user-owned contradictions. Invalid provider output is a rejected diagnostic. Maintenance ticks supersede `needs_confirmation` entries older than the default 30-day TTL and retain their evidence rows.

## Memory Atlas navigation

For broad inventory or historical questions call `cogmem_graph_explore`. Use `cogmem_graph_search` and `cogmem_graph_node` for known concepts, `cogmem_graph_neighbors`/`cogmem_graph_path` for relations, and `cogmem_graph_timeline` for ordered reconstruction. Use `cogmem_recall` for a direct fact and follow event IDs or returned `sourceLocator` commands to `cogmem memory show` for exact wording.

Combine the filters present in the user's message, including project, time, topic, entity/target, memory kind, and ordinary cues. Do not force an entity + time + action tuple. A cold result is newly visible, not newly verified or promoted.
