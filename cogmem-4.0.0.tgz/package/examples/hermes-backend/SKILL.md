---
name: cogmem-memory-backend
description: Install, connect, import, inspect, and navigate cogmem as Hermes's durable MCP memory backend. Use for broad memory inventory, historical or relationship questions, exact source drill-down, Memory Atlas graph exploration, episode/Dream maintenance, or MCP wiring repair.
---

# cogmem Memory Backend for Hermes

Use this skill when a Hermes workspace needs `cogmem` as its durable memory backend.

For the complete command matrix, import recipes, governance actions, Atlas filters, repair commands, backup flow, and scheduler guidance, read [references/operations.md](references/operations.md).

## Ground Rules

- Use TOML config only: `~/.cogmem/config.toml` or project `.cogmem/config.toml`.
- Do not create .cogmem.env files.
- Do not pass `--env-path`.
- Do not configure kernel behavior through hidden environment variables; write TOML instead.
- Do not run a separate vector search before calling `memory.recall()`. `KernelAgentMemoryBackend.recall()` is the first-class recall path and already performs pulse activation, temporal traversal, graph traversal, and narrative assembly.
- Do not set `memory.provider: cogmem` in `~/.hermes/config.yaml`; this package uses Hermes MCP integration, not a native Hermes memory provider.
- Treat entity aliases as governed candidates. Never merge people from pronouns, family labels, job titles, assistant text, or tool output alone; require explicit user evidence and leave uncertain matches pending.
- Treat Belief Graph nodes as evidence-backed cognition. Assistant/tool-only observations may describe project state but must never become user preferences, goals, boundaries, or facts; inspect source events before accepting or correcting a belief.
- For "when", "before", "why did this change", or "what was current then" questions, use Temporal Memory validity windows and timeline evidence. Do not present a superseded belief as current or mix old and current project state.
- Let Context Cortex decide activation: greetings use no Cogmem memory; short same-topic continuations use Session State and Turn Bridge; exact-quote requests prioritize raw source; other recall remains within the configured memory budget. Read `activationReceipt` before claiming that memory did not exist.
- Prospective Memory is candidate state, not an instruction queue. Only explicit user evidence can confirm a reminder/commitment; listing a due candidate never authorizes tool or task execution. Use `cogmem prospective` to inspect or resolve state and `cogmem brain-eval` before release.

```bash
cogmem prospective list --project <projectId>
cogmem prospective confirm --project <projectId> --id <candidateId> --evidence <distinctUserEventId>
cogmem prospective due --project <projectId>
```

## Install

Run from the Hermes workspace root. Prefer a workspace-local npm dependency so Hermes and Cogmem upgrade together:

```bash
npm install cogmem@latest --save
COGMEM="./node_modules/.bin/cogmem"
"$COGMEM" doctor
"$COGMEM" connect hermes --workspace . --auto --force --json
```

If the workspace already has Cogmem installed locally, keep using the local binary. If there is no local binary but a global install exists, use global. If neither exists, install first:

```bash
if [ -x ./node_modules/.bin/cogmem ]; then
  COGMEM="./node_modules/.bin/cogmem"
elif command -v cogmem >/dev/null 2>&1; then
  COGMEM="cogmem"
else
  npm install cogmem@latest --save
  COGMEM="./node_modules/.bin/cogmem"
fi
```

Global npm is also supported when the operator wants one CLI for every workspace:

```bash
npm install -g cogmem@latest
COGMEM="cogmem"
"$COGMEM" connect hermes --workspace . --auto --force --json
```

The one-line installer remains available for machines that do not already have Bun. Use `COGMEM_SKIP_INIT=1` for agent-run installs so the installer does not start the interactive wizard:

```bash
COGMEM_SKIP_INIT=1 curl -fsSL https://raw.githubusercontent.com/liuqin164/cogmem/main/install.sh | bash
COGMEM="cogmem"
"$COGMEM" connect hermes --workspace . --auto --force --json
```

Do not run `cogmem init` as an unattended agent action. `cogmem init` is an interactive configuration wizard. Use it only when an operator is present or explicitly asks for a guided setup:

```bash
"$COGMEM" init --agent hermes --scope project
```

Hermes workspaces should normally use project-local config when the workspace owns its memory:

```text
.cogmem/config.toml
.cogmem/memory.db
.cogmem/snapshots/
```

To embed imported memories with a local quantized model, run Ollama locally and configure the kernel before importing:

```bash
ollama pull qwen3-embedding:0.6b
```

```toml
[core]
vector_dimension = 1024

[embedding]
provider = "openai_compatible"
base_url = "http://localhost:11434/v1"
model = "qwen3-embedding:0.6b"
```

Use the matching dimension for larger local models: `qwen3-embedding:4b` uses `2560`; `qwen3-embedding:8b` uses `4096`. Run `cogmem doctor` after editing. Imported records are embedded through the configured kernel embedder during `cogmem import-hermes`.

Also configure `[memory_model]` for the Dream Curator. Embeddings are for recall; the memory model is the LLM that proposes candidate summaries, preferences, tags, conflicts, and diagnostics:

```toml
[memory_model]
provider = "openai_compatible"
base_url = "http://localhost:11434/v1"
model = "qwen2.5:7b"
api_key = ""
timeout_ms = 60000
```

## Import Existing Hermes Memory

Cogmem 4.0 is a clean start and does not migrate or upgrade a pre-4.0 database. Opening a Cogmem 3.x database is refused with an error code beginning `no_upgrade_path:`, and the file is left exactly as it was — no backup, no partial rewrite. Keep that file for Cogmem 3.x, or point 4.0 at a new database path (a new `db_path` in the config, or `--db` for one command) and move history across from the 3.x install. There is no upgrade command; creating a new database is the supported path.

After updating the package, refresh the host integration before importing or recalling:

```bash
cogmem update --yes
cogmem connect hermes --workspace . --auto --force --json
```

`cogmem update --yes` installs `cogmem@latest` from npm, refreshes the Hermes MCP wiring when the integration is configured, and ends on the same `cogmem doctor` install gate a fresh install ends on. It runs no migration step. For npm global installs, `cogmem update --yes` resolves to `npm install -g cogmem@latest` instead of writing into the current directory. Agents should inspect `cogmem update --dry-run --json` when an operator wants a preview.

Default Hermes memory contract:

- `state.db` may contain the real chronological conversation history in SQLite `messages`.
- `profile.md` contains durable profile/persona memory.
- `sessions/**/*.md` contains conversation/session memory.

Always preview first:

```bash
# Importing defaults to this workspace's own scope: the project the installed
# integration writes to and reads. Read it from: cogmem connect hermes --auto --json
# (field: integrationProject). Pass --project only to import somewhere else — a
# literal --project hermes writes into a scope the MCP server is not bound to.
cogmem import-hermes --workspace . --dry-run
```

If `state.db` exists, the default import scans it automatically. Use an explicit path when the database is outside the workspace:

```bash
cogmem import-hermes --workspace . --state-db ./state.db --dry-run
cogmem import-hermes --workspace . --state-db ./state.db
```

The SQLite importer reads the `messages` table, preserves row/message order, supports WAL-mode read-only databases through SQLite immutable mode, and prefers message-level `occurredAt`, `timestamp`, or `createdAt`. Numeric `timestamp` values below millisecond range are epoch seconds. `InsertTime` is only a fallback and must not be treated as the original conversation time.

Then import:

```bash
cogmem import-hermes --workspace .
```

Use JSON output when another agent is orchestrating the run:

```bash
cogmem import-hermes --workspace . --json
```

If Hermes stores memory somewhere else, pass explicit paths:

```bash
cogmem import-hermes --workspace . --profile ./memory/profile.md --sessions ./memory/sessions
cogmem import-hermes --workspace . --session ./one.md
cogmem import-hermes --workspace . --session ./one.md --session ./two.md
```

For Hermes JSONL session exports where each line is a session object with `messages[]`, normalize first:

```bash
cogmem normalize-transcript --input ./hermes-sessions.jsonl --output ./hermes.normalized.md --family jsonl --dry-run --json
cogmem normalize-transcript --input ./hermes-sessions.jsonl --output ./hermes.normalized.md --family jsonl
cogmem import-hermes --workspace . --session ./hermes.normalized.md
```

The importer is idempotent. Re-running it skips records already imported into the same memory database.

Cogmem skips import batch sealing for empty episode boundaries and Dream skips legacy empty episode jobs instead of blocking the whole queue. If `episode status` shows `dreamError` beginning with `episode_empty`, inspect the source events and use episode repair instead of editing SQLite rows.

Run the maintenance loop under host supervision after import and during normal use. `needs_confirmation` is a human review queue, not the Dream backlog, and `memory govern` promotes only ordinary `candidate` rows:

```bash
cogmem memory plan --project 'hermes-<workspace-hash>' --json
cogmem memory status --project 'hermes-<workspace-hash>' --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --json
cogmem episode status --project 'hermes-<workspace-hash>' --json
cogmem dream status --project 'hermes-<workspace-hash>' --json
cogmem dream tick --project 'hermes-<workspace-hash>' --mode auto --max-episodes 20 --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --status candidate --json
cogmem memory govern --project 'hermes-<workspace-hash>' --limit 100 --json
cogmem memory candidates --project 'hermes-<workspace-hash>' --status needs_confirmation --json
cogmem memory review --project 'hermes-<workspace-hash>' --id <candidate-id> --action approve --actor <operator> --reason "confirmed by user" --confirmation-event <distinct-user-event-id> --json
cogmem memory recall --query "<verification question>" --project 'hermes-<workspace-hash>' --agent hermes --json
```

`memory plan` is the first agent-safe health and next-action command. It explains which queues block release, which work is non-blocking, whether vectors are empty but fallback recall is available, and what command should run next. Only run `dream_tick` when it appears in `nextActions`; if `nonBlocking` contains `raw_dream_ledger_lag` with `resolvableByDreamTick:false`, inspect raw sources or episode/import boundaries instead of retrying `dream tick`. Default `memory candidates --json` groups ordinary candidates, `needs_confirmation`, and deferred review entries; use `--status` only when the operator asks for one queue.

A host timer may run this bounded tick periodically. The tick exits after inspecting the backlog and performs no work when no sealed episode is ready.

## Active Memory Search

Choose the graph tool from the question shape:

- Broad inventory/history: `cogmem_graph_explore`.
- Known concept: `cogmem_graph_search`, then `cogmem_graph_node`.
- Nearby relations: `cogmem_graph_neighbors`.
- Connection between known nodes: `cogmem_graph_path`.
- Time-ordered reconstruction: `cogmem_graph_timeline`.
- Direct factual question: `cogmem_recall`.
- Exact wording: follow an event ID with `cogmem memory show`.

Atlas combines whatever conditions the user supplies like table filters. Do not require entity + time + action. Project, day/month/year, topic, issue, entity/target, session/thread, memory kind, action kind, and ordinary cues may revive cold nodes together. Entity cue extraction accepts Unicode letter/number names, but it is not full NER and must not be treated as proof that two aliases are the same person/tool. Activation is visibility, not truth. Atlas summaries are hints and never replace raw evidence.

In 3.7.2, `cogmem_graph_search`, `cogmem_graph_explore`, and historical recall can return canonical `cards[]`. Prefer cards over raw node labels for past-discussion questions. A card's `canonicalId` is the single episode identity; `matchedFacets` explains time/topic/issue/entity matches; `matchedPaths` explains how the card was reached; `relatedButNotSelected` is context only and must not replace the selected answer; `sourceLocator.command` is the command to inspect exact original text. If `relaxationTrace` exists, say the answer is a relaxed match, not an exact hit; supported relaxations include day → month → year and issue → parent topic.

When the prompt does not contain enough injected Cogmem context, do not search legacy memory files first. Ask Cogmem directly:

```bash
cogmem memory recall --query "<user question>" --project 'hermes-<workspace-hash>' --agent hermes --json
```

For inventory or product-memory questions, raw recall works even before vectors are built:

```bash
cogmem memory recall --query "我们记录过哪些库存" --project 'hermes-<workspace-hash>' --agent hermes --json
cogmem memory search --query "エルビ 库存" --project 'hermes-<workspace-hash>' --json
```

If recall returns an item with `sourceContext.locator.command`, use that command to drill into the exact ledger event:

```bash
cogmem memory show --event <event-id> --before 2 --after 2 --json
```

`sourceContext` entries include stable `label` values, optional `charRange` / `sourceRange`, and `sourceContext.window` metadata. Use `window.before.requestedCount`, `window.before.count`, `window.after.requestedCount`, `window.after.count`, `excludesAnchor`, `ordering`, `roleFilter`, and `overlapHandling` to understand the before/after replay. `memory show --json` returns the same contract, so the labels in MCP recall can be matched to the local CLI output.

For “did we discuss this before?”, “几个月前是不是聊过…”, “记忆黑盒”, MCP memory gaps, or other old-discussion questions, force the historical-discussion lane before saying memory is absent:

```bash
cogmem memory recall --query "<past discussion question>" --intent historical_discussion --project 'hermes-<workspace-hash>' --agent hermes --json
```

For action-history questions such as “what did I ask you to do to <entity>?”, “启动 <tool>”, or “对 <entity> 做过什么操作”, use `action_history` or Atlas timeline. The entity is whatever project/tool/person/service the user mentions in memory; it is not limited to Hermes itself:

```bash
cogmem memory recall --query "我之前让你对 <实体或工具名> 做过什么" --intent action_history --project 'hermes-<workspace-hash>' --agent hermes --json
cogmem memory graph-timeline --project 'hermes-<workspace-hash>' --query "对 <实体或工具名> 做过什么操作" --include-evidence --json
```

If the answer depends on exact wording or nearby context, run the returned `sourceLocator` or use a Raw Ledger cursor:

```bash
cogmem memory show --event <eventId> --project 'hermes-<workspace-hash>' --before 2 --after 2 --json
cogmem memory list --project 'hermes-<workspace-hash>' --since <globalSeq> --order asc --json
```

Raw list rows and Atlas search/explore evidence include `sourceLocator.command` and a deeper `sourceLocator.contextCommand`. Use those commands before claiming an event ID is missing, before quoting exact words, or before treating an Atlas summary as the source.

`vectors: 0` does not mean memory is unavailable. It means dense vector search has no hot index yet; `memory recall` still has governed raw-ledger fallback. Broad inventory questions are expanded into structured cues such as `库存管理`, `在库`, `产品コード`, and `数量`; when compiled candidates miss those cues, prefer the raw ledger result and use its `sourceContext` for details. Check status with:

```bash
cogmem memory plan --project 'hermes-<workspace-hash>' --json
cogmem memory status --project 'hermes-<workspace-hash>' --json
```

Use top-level counters `rawEvents`, `vectors`, `dreamedRawCount`, `undreamedRawCount`, and `dreamCoverageRate` for machine decisions.

Use collection routing when Hermes stores creative artifacts or drafts that should not pollute normal operational recall:

```bash
cogmem memory recall --query "<artifact query>" --project 'hermes-<workspace-hash>' --agent hermes --collection theseus --json
```

Default recall includes untagged and `collection:anchor` memory only. Ask for `collection:theseus` explicitly when the user wants creative/reference artifacts.

For host upkeep, inspect the self-map and run an explicit tick:

```bash
cogmem memory plan --project 'hermes-<workspace-hash>' --json
cogmem memory map --project 'hermes-<workspace-hash>' --json
cogmem memory tick --project 'hermes-<workspace-hash>' --json
cogmem memory bind --project 'hermes-<workspace-hash>' --json
```

`memory tick` does not start a daemon. Use its `suggestedActions` to decide whether Hermes should run `dream tick`, `memory govern`, `episode repair`, entity review, re-embedding, or `memory bind` for unbound high-value raw events. `undreamedRawCount` by itself is Raw Ledger coverage lag, not a sealed-episode job; do not loop `dream tick` unless `memory plan.nextActions` contains `dream_tick`. `memory bind` scans the historical Raw Ledger by cursor instead of only the latest page; resume large repairs with `--since <globalSeq>`.

`memory map` also exposes Memory Binding and Graph Recall counters. Bindings connect high-value user raw events to stable topic/entity paths before promotion, fuse same-claim evidence into claim-key clusters, and create graph anchors for source drill-down. Correction bindings expose review flags and correction edges. Use graph recall hits for source drill-down and topic continuity only; do not treat bindings, clusters, or edges as verified facts, user preferences, or prompt instructions.

MCP `cogmem_recall` and `cogmem_explain_recall` expose the same `decisionTrace`. Check `selectedLane`, `reason`, and `candidateCounts` before claiming memory is absent, then follow `sourceContext.locator.command` for exact wording. Raw fallback searches the fully scoped ledger; equal raw cue matches prefer original user anchors, and past-memory queries prefer a cue-matching raw user anchor over a compiled assistant retelling.

Explicit user clarification is organizational correction evidence, not an automatic contradiction. Assistant self-correction and negative-form questions do not create user-owned corrections. A memory-model conflict proposal must cite at least two distinct exact raw event IDs from the current Dream window; `["all"]` and unknown IDs are rejected. Invalid memory-model output remains a rejected diagnostic. Review `needs_confirmation` with `cogmem_candidate_review` or `cogmem memory review`; maintenance only supersedes entries that remain stale past the default 30-day TTL.

When importing OpenClaw-style session Markdown into a Hermes project, Cogmem accepts multiline bodies below empty role headers, collapses only adjacent exact export duplicates, and uses `# Session: ... UTC` as the chronological timestamp base rather than file mtime.

After upgrading, rerun `cogmem connect hermes --workspace . --auto --force --json` and reload MCP so existing allow-lists and skill instructions receive the current tools and contracts. In JSON output, follow only `nextCommands` for unattended agent work; unsafe operator or host steps such as interactive init and `/reload-mcp` are listed under `nextSteps` with `safeForAutomation=false`.

## Runtime Wiring

Use `KernelAgentMemoryBackend` for turn storage and recall:

```ts
import {
  KernelAgentMemoryBackend,
  createMemoryKernelFromConfig,
} from 'cogmem';

const kernel = createMemoryKernelFromConfig();
const memory = new KernelAgentMemoryBackend(kernel);

await memory.rememberTurn({
  agentId: 'hermes',
  projectId: 'hermes',
  sessionId,
  userText,
  assistantText,
});

const recall = memory.recall({
  agentId: 'hermes',
  projectId: 'hermes',
  query: userText,
});

const preparedContext = {
  mode: recall.recallMode,
  narrative: recall.narrative,
  pulseTrace: recall.pulseTrace,
  temporalLabels: recall.temporalTraversal?.labels,
  memories: recall.items,
};
```

Use `recall.narrative` as the compact prompt context and `recall.items` as cited memory evidence. If `recall.recallMode === 'universe_navigation'`, the memory kernel has already prepared related context through the pulse/temporal/narrative path.

If Hermes can consume structured context before answering, prefer `memory.recallPack()` over plain `recall()`:

```ts
const pack = memory.recallPack({
  agentId: 'hermes',
  projectId: 'hermes',
  query: userText,
  limit: 5,
});
```

Use `pack.slots.direct` for direct memories, `pack.slots.associative` for graph/activation neighbors, `pack.slots.entityCards` for resolved projects/devices/people, and `pack.slots.beliefTouches` for active beliefs with support/conflict counts.

## Hermes Provider Notes

Hermes external memory providers are activated through `memory.provider` in `~/.hermes/config.yaml` and participate in lifecycle calls such as initialization, prompt context, prefetch, turn sync, session-end extraction, and built-in memory write mirroring.

Do not edit `~/.hermes/config.yaml` to point `memory.provider` at `cogmem` until a Hermes native provider plugin exists on disk. The supported bridge in this package is MCP.

`cogmem connect hermes` installs this file plus `references/operations.md` into `~/.hermes/skills/cogmem-memory/`, which is Hermes's primary skill directory.

`cogmem connect hermes --workspace . --auto --force` patches `~/.hermes/config.yaml` with this MCP server:

```yaml
mcp_servers:
  cogmem:
    command: "/resolved/path/to/cogmem"
    args: ["mcp"]
    enabled: true
    tools:
      include:
        - cogmem_remember_turn
        - cogmem_recall
        - cogmem_explain_recall
        - cogmem_strategy_plan
        - cogmem_episode_append
        - cogmem_episode_import
        - cogmem_episode_status
        - cogmem_topic_list
        - cogmem_topic_operate
        - cogmem_topic_rollback
        - cogmem_episode_repair
        - cogmem_episode_seal
        - cogmem_dream_tick
        - cogmem_dream_status
        - cogmem_memory_map
        - cogmem_graph_overview
        - cogmem_graph_search
        - cogmem_graph_explore
        - cogmem_graph_node
        - cogmem_graph_neighbors
        - cogmem_graph_path
        - cogmem_graph_timeline
        - cogmem_graph_touch
        - cogmem_candidate_review
        - cogmem_maintenance_tick
        - cogmem_prospective
```

The command path is resolved by `cogmem connect hermes`: it uses `COGMEM_BIN` when explicitly set, then a workspace-local `node_modules/.bin/cogmem`, then the CLI this machine resolves — the absolute launcher when `cogmem` is not on `PATH`, the bare name when it is — and passes `mcp` as the first argument. `COGMEM_MCP_BIN` and `cogmem-mcp` remain compatibility paths for existing host configs.

When Hermes calls `cogmem_recall`, it should **omit `projectId`**: the MCP server `connect` wired is bound to this workspace's scope, and naming a different project is rejected with `project_scope_violation`. `agentId` may also be omitted; the bridge infers it from the bound project. The returned `items` use the same shape as `cogmem memory recall --project 'hermes-<workspace-hash>' --agent hermes --json`, including `raw_ledger` items, labeled `sourceContext` events, `sourceContext.window`, and `sourceContext.locator.command` when vectors are empty or compiled evidence misses.

Hermes may pass `collection: "theseus"` to `cogmem_recall` when it wants creative artifacts. `cogmem_strategy_plan` is a read-only inspection tool: its capsule has no instruction authority and never authorizes work. Expose `cogmem_memory_map` and `cogmem_maintenance_tick` only to agents that are allowed to inspect memory anatomy or request host-owned upkeep. `cogmem_prospective` manages candidate state only; even a confirmed due item requires normal host authorization before any action.

Cogmem cannot observe Hermes conversations without a host hook or explicit MCP/import call. After meaningful conversation, call `cogmem_episode_append` with a stable `externalMessageId`, or use bounded `cogmem_episode_import` for a batch. Before answering memory questions, call `cogmem_recall`. The ID is scoped to project, source agent, and source session; conflicting role, text, or `sourceAgent` metadata is rejected. If any batch item lacks an ID, honor `auto_identity_not_safe_across_split_batches`: assign stable IDs before splitting/retrying the batch.

Append/import preserve Raw Ledger evidence and never run Dream. MCP import is capped at 200 messages and reports `processedCount`, `failedIndex`, `resumeFromIndex`, and per-message results. Use the streaming CLI with checkpoints and line/error bounds for large histories. Inspect `recommendedActions`, not a single action. If recall/status warns `no_recent_episode_ingestion_detected`, append/import recent messages; if it warns `semantic_memory_may_lag`, inspect open/soft-sealed episodes and Dream failures before claiming memory is current. Call `cogmem_dream_tick` with `maintenanceMode: true` only during explicit background upkeep.

Use `cogmem_topic_operate` with actor `user_explicit` only for the user's explicit naming, alias, move, merge, split, or relation instruction. Model guesses use `model_candidate` and must not become active automatically. Inspect project-scoped nodes with `cogmem_topic_list`; alias collisions require review, and undo with `cogmem_topic_rollback` plus the returned `operationId`. Use `cogmem_episode_repair` for bad boundaries so closure receipts, stale candidates, Dream requeue, cross-references, and audit state remain consistent; never patch SQLite rows manually.

Then reload MCP inside Hermes:

```text
/reload-mcp
```

When authoring a future native Hermes provider, map Hermes behavior to core like this:

- Provider initialization should call `createMemoryKernelFromConfig()`.
- Prompt context and prefetch should call `memory.recall()` and inject `recall.narrative`.
- Turn sync should call `memory.rememberTurn()` after each response.
- Built-in memory writes should be mirrored through `memory.rememberTurn()` or direct kernel ingest with `agentId: 'hermes'`.
- Search tools should return `recall.narrative` plus cited `recall.items`, not a raw vector nearest-neighbor dump.

After native provider wiring exists, a minimal host config shape is:

```yaml
memory:
  provider: cogmem
```

If using a future MCP bridge instead, add it under `mcp_servers` in `~/.hermes/config.yaml` and expose only the recall/write tools needed by the agent.
